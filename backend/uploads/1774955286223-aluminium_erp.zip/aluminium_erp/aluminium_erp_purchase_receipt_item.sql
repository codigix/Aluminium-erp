-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: aluminium_erp
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `purchase_receipt_item`
--

DROP TABLE IF EXISTS `purchase_receipt_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_receipt_item` (
  `grn_item_id` varchar(50) NOT NULL,
  `grn_no` varchar(50) NOT NULL,
  `item_code` varchar(100) NOT NULL,
  `received_qty` decimal(10,2) DEFAULT NULL,
  `accepted_qty` decimal(10,2) DEFAULT NULL,
  `rejected_qty` decimal(10,2) DEFAULT NULL,
  `warehouse_code` varchar(50) DEFAULT NULL,
  `batch_no` varchar(100) DEFAULT NULL,
  `quality_inspection_required` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`grn_item_id`),
  UNIQUE KEY `grn_item_id` (`grn_item_id`),
  UNIQUE KEY `grn_item_id_2` (`grn_item_id`),
  KEY `item_code` (`item_code`),
  KEY `idx_grn` (`grn_no`),
  CONSTRAINT `purchase_receipt_item_ibfk_1` FOREIGN KEY (`grn_no`) REFERENCES `purchase_receipt` (`grn_no`),
  CONSTRAINT `purchase_receipt_item_ibfk_2` FOREIGN KEY (`item_code`) REFERENCES `item` (`item_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_receipt_item`
--

LOCK TABLES `purchase_receipt_item` WRITE;
/*!40000 ALTER TABLE `purchase_receipt_item` DISABLE KEYS */;
INSERT INTO `purchase_receipt_item` VALUES ('669fe8ff-0ad0-4b1e-9476-9a229f1ce89e','GRN-1762346382674','ITEM-001',10.00,0.00,NULL,NULL,NULL,1,'2025-11-05 12:39:42');
/*!40000 ALTER TABLE `purchase_receipt_item` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-14 18:08:18
