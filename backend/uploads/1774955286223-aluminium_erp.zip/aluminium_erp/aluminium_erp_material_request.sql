-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: aluminium_erp
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `material_request`
--

DROP TABLE IF EXISTS `material_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `material_request` (
  `mr_id` varchar(50) NOT NULL,
  `requested_by_id` varchar(50) DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `required_by_date` date DEFAULT NULL,
  `status` enum('draft','approved','converted','cancelled') DEFAULT 'draft',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` varchar(100) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`mr_id`),
  KEY `requested_by_id` (`requested_by_id`),
  CONSTRAINT `material_request_ibfk_1` FOREIGN KEY (`requested_by_id`) REFERENCES `contact` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `material_request`
--

LOCK TABLES `material_request` WRITE;
/*!40000 ALTER TABLE `material_request` DISABLE KEYS */;
INSERT INTO `material_request` VALUES ('MR-1761912349071','CONT-003','Production','2025-10-31','2025-11-01','draft','2025-10-31 12:05:49',NULL,'2025-10-31 12:05:49',NULL),('MR-1761912362410','CONT-003','Production','2025-10-31','2025-11-01','draft','2025-10-31 12:06:02',NULL,'2025-10-31 12:06:02',NULL),('MR-1761912413365','CONT-003','Production','2025-10-31','2025-11-01','draft','2025-10-31 12:06:53',NULL,'2025-10-31 12:06:53',NULL),('MR-1761912598847','CONT-003','Maintenance','2025-10-31','2025-11-01','draft','2025-10-31 12:09:58',NULL,'2025-10-31 12:09:58',NULL),('MR-1761912959534','CONT-003','Maintenance','2025-10-31','2025-11-01','draft','2025-10-31 12:15:59',NULL,'2025-10-31 12:15:59',NULL),('MR-1761912995247','CONT-003','Maintenance','2025-10-31','2025-11-01','approved','2025-10-31 12:16:35',NULL,'2025-11-05 12:05:46',NULL),('MR-1761913075231','CONT-003','Maintenance','2025-10-31','2025-11-01','approved','2025-10-31 12:17:55',NULL,'2025-10-31 12:18:06',NULL);
/*!40000 ALTER TABLE `material_request` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-11-14 18:08:18
