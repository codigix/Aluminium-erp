-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: sales_erp
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `stock_balance`
--

DROP TABLE IF EXISTS `stock_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stock_balance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `item_code` varchar(100) NOT NULL,
  `item_description` text,
  `po_qty` decimal(12,3) DEFAULT '0.000',
  `received_qty` decimal(12,3) DEFAULT '0.000',
  `accepted_qty` decimal(12,3) DEFAULT '0.000',
  `issued_qty` decimal(12,3) DEFAULT '0.000',
  `current_balance` decimal(12,3) DEFAULT '0.000',
  `unit` varchar(20) DEFAULT NULL,
  `last_updated` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `material_name` varchar(255) DEFAULT NULL,
  `material_type` varchar(100) DEFAULT NULL,
  `valuation_rate` decimal(12,2) DEFAULT '0.00',
  `selling_rate` decimal(12,2) DEFAULT '0.00',
  `no_of_cavity` int DEFAULT '1',
  `weight_per_unit` decimal(12,3) DEFAULT '0.000',
  `weight_uom` varchar(20) DEFAULT NULL,
  `drawing_no` varchar(120) DEFAULT NULL,
  `revision` varchar(50) DEFAULT NULL,
  `material_grade` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `item_code` (`item_code`),
  KEY `idx_item_code` (`item_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stock_balance`
--

LOCK TABLES `stock_balance` WRITE;
/*!40000 ALTER TABLE `stock_balance` DISABLE KEYS */;
INSERT INTO `stock_balance` VALUES (1,'ITM-0001',NULL,0.000,0.000,0.000,0.000,0.000,'Nos','2026-01-20 05:20:39','MS PLATE – IS 2062 E250','Raw Material',345.00,345.00,1,0.850,'Kg','9000011003','1234567890','5'),(3,'ITM-0003',NULL,0.000,0.000,0.000,0.000,0.000,'Kg','2026-01-20 05:42:24','Hex Bolt M8 × 20','Raw Material',100.00,100.00,1,0.600,'Kg','9000011003','1234567890','4'),(4,'ITM-0004',NULL,0.000,0.000,0.000,0.000,0.000,'Nos','2026-01-20 05:44:31','Plain Washer M8','Raw Material',20.00,20.00,1,23.000,'Gm','9000011003','1234567890','6'),(5,'ITM-0005',NULL,0.000,0.000,0.000,0.000,0.000,'Nos','2026-01-20 05:46:22','Steel Bush Ø10 × Ø8 × 15','Raw Material',10.00,10.00,1,1.800,'Kg','	9000011003','234567890','4');
/*!40000 ALTER TABLE `stock_balance` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-20 13:51:04
