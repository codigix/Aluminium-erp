-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: sales_erp
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_po_items`
--

DROP TABLE IF EXISTS `customer_po_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_po_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `customer_po_id` int NOT NULL,
  `item_code` varchar(120) DEFAULT NULL,
  `description` text NOT NULL,
  `hsn_code` varchar(50) DEFAULT NULL,
  `drawing_no` varchar(120) DEFAULT NULL,
  `revision_no` varchar(50) DEFAULT NULL,
  `quantity` decimal(12,3) DEFAULT '0.000',
  `unit` varchar(20) DEFAULT 'NOS',
  `rate` decimal(12,2) DEFAULT '0.00',
  `basic_amount` decimal(14,2) DEFAULT '0.00',
  `discount` decimal(12,2) DEFAULT '0.00',
  `cgst_percent` decimal(5,2) DEFAULT '0.00',
  `cgst_amount` decimal(12,2) DEFAULT '0.00',
  `sgst_percent` decimal(5,2) DEFAULT '0.00',
  `sgst_amount` decimal(12,2) DEFAULT '0.00',
  `igst_percent` decimal(5,2) DEFAULT '0.00',
  `igst_amount` decimal(12,2) DEFAULT '0.00',
  `delivery_date` date DEFAULT NULL,
  `purchase_req_no` varchar(120) DEFAULT NULL,
  `customer_reference` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_po_id` (`customer_po_id`),
  CONSTRAINT `customer_po_items_ibfk_1` FOREIGN KEY (`customer_po_id`) REFERENCES `customer_pos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_po_items`
--

LOCK TABLES `customer_po_items` WRITE;
/*!40000 ALTER TABLE `customer_po_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_po_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-20 13:51:03
