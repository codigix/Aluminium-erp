-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: sales_erp
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` text,
  `resource` varchar(120) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `status` enum('ACTIVE','INACTIVE') DEFAULT 'ACTIVE',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=2844 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'View POs','PO_VIEW','View customer purchase orders','customer_pos','read','ACTIVE','2026-01-13 15:26:31'),(2,'Create PO','PO_CREATE','Create new customer POs','customer_pos','create','ACTIVE','2026-01-13 15:26:31'),(3,'Edit PO','PO_EDIT','Edit customer POs','customer_pos','update','ACTIVE','2026-01-13 15:26:31'),(4,'Delete PO','PO_DELETE','Delete customer POs','customer_pos','delete','ACTIVE','2026-01-13 15:26:31'),(5,'View Orders','ORDER_VIEW','View sales orders','sales_orders','read','ACTIVE','2026-01-13 15:26:31'),(6,'Create Orders','ORDER_CREATE','Create sales orders','sales_orders','create','ACTIVE','2026-01-13 15:26:31'),(7,'Edit Orders','ORDER_EDIT','Edit sales orders','sales_orders','update','ACTIVE','2026-01-13 15:26:31'),(8,'View Companies','COMPANY_VIEW','View company data','companies','read','ACTIVE','2026-01-13 15:26:31'),(9,'Edit Companies','COMPANY_EDIT','Edit company data','companies','update','ACTIVE','2026-01-13 15:26:31'),(10,'Manage Users','USER_MANAGE','Manage users and permissions','users','all','ACTIVE','2026-01-13 15:26:31'),(11,'Manage Departments','DEPT_MANAGE','Manage departments','departments','all','ACTIVE','2026-01-13 15:26:31'),(12,'Export Data','DATA_EXPORT','Export data and reports','reports','read','ACTIVE','2026-01-13 15:26:31'),(13,'View Dashboard','DASHBOARD_VIEW','View dashboard','dashboard','read','ACTIVE','2026-01-13 15:26:31'),(14,'Change Order Status','STATUS_CHANGE','Change order status','sales_orders','update_status','ACTIVE','2026-01-13 15:26:31');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-20 13:51:06
