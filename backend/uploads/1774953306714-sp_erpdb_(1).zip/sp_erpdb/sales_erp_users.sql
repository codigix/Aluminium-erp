-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: sales_erp
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(120) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(120) DEFAULT NULL,
  `last_name` varchar(120) DEFAULT NULL,
  `department_id` int NOT NULL,
  `role_id` int NOT NULL,
  `status` enum('ACTIVE','INACTIVE') DEFAULT 'ACTIVE',
  `phone` varchar(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `department_id` (`department_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@company.com','$2b$10$t9Q9dy9NYqWGmk0Y.XbAhOKYiyNUV93VhnG1TVUtM763QUZQKBBAK','Admin','User',9,9,'ACTIVE','9876543210','2026-01-13 15:31:06','2026-01-13 15:31:06'),(2,'sales_user','sales@company.com','$2b$10$svQ.N5X4/cHaHDxo0XJ7J.GieBJpw2svIMHG7ty0aSneTg6RVGsBO','John','Sales',1,1,'ACTIVE','9876543211','2026-01-13 15:31:06','2026-01-13 15:31:06'),(3,'design_user','design@company.com','$2b$10$Cc4aHSh/SBjX0qfaGNcYhu46hbpyjS3uwuUju7Vaz1EX1t8J6BOrC','Jane','Design',2,2,'ACTIVE','9876543212','2026-01-13 15:31:06','2026-01-13 15:31:06'),(4,'procurement_user','procurement@company.com','$2b$10$Xhg5Ul5eDHI8bKrw/aWtWOSjFUFQJZqTVDD5tCSV9n2q8D8y.2fym','Robert','Procurement',3,3,'ACTIVE','9876543216','2026-01-13 15:31:06','2026-01-13 15:31:06'),(5,'production_user','production@company.com','$2b$10$HyKfLXr1WvTstp6D5fAT2unl5fZqH3LudGPLncCkVlidujjl4DPvG','Mike','Production',4,4,'ACTIVE','9876543213','2026-01-13 15:31:06','2026-01-13 15:31:06'),(6,'accounts_user','accounts@company.com','$2b$10$uZYuzUZoXNSxeUHaR1y5HehYbwx7cw0Izhs4zfXwd3DnlRYypxI4.','Sarah','Accounts',7,7,'ACTIVE','9876543214','2026-01-13 15:31:07','2026-01-13 15:31:07'),(7,'shipment_user','shipment@company.com','$2b$10$./pk0KB5FmFdsue5wL6RY.UIoXJxfYBd9jBbyQWt9WIgC/qgoDhmS','David','Shipment',6,6,'ACTIVE','9876543215','2026-01-13 15:31:07','2026-01-13 15:31:07'),(8,'quality_user','quality@company.com','$2b$10$q1LpF1CxMagAzmvSoLo3ruFDq8dCaLhFFH5FDxEZaXPoe3WUFvrBq','Alice','Quality',5,5,'ACTIVE','9876543217','2026-01-13 15:31:07','2026-01-13 15:31:07'),(9,'inventory_user','inventory@company.com','$2b$10$sqzE4CURGjM5Haf0FEVJ9exU4HRRpMB/Ywd7nO6hiwsZVt5Y5tKaS','Bob','Inventory',8,8,'ACTIVE','9876543218','2026-01-13 15:31:07','2026-01-13 15:31:07'),(10,'sales','sales@aluminium.com','$2b$10$B7RXcro5dzEkmoFdiV3EzOCj1sFvN2dtdBfF61yTxWu0BiyjlKlA6','Ashwini','Khedekar',1,1,'ACTIVE',NULL,'2026-01-13 15:31:57','2026-01-13 15:31:57');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-20 13:51:04
