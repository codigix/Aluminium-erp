-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: sales_erp
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer_pos`
--

DROP TABLE IF EXISTS `customer_pos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_pos` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_id` int NOT NULL,
  `po_number` varchar(100) DEFAULT NULL,
  `po_date` date DEFAULT NULL,
  `po_version` varchar(20) DEFAULT NULL,
  `order_type` varchar(40) DEFAULT NULL,
  `plant` varchar(120) DEFAULT NULL,
  `currency` varchar(10) DEFAULT 'INR',
  `payment_terms` varchar(255) DEFAULT NULL,
  `credit_days` int DEFAULT NULL,
  `freight_terms` varchar(255) DEFAULT NULL,
  `packing_forwarding` varchar(255) DEFAULT NULL,
  `insurance_terms` varchar(255) DEFAULT NULL,
  `delivery_terms` varchar(255) DEFAULT NULL,
  `status` enum('DRAFT','APPROVED','REJECTED') DEFAULT 'DRAFT',
  `pdf_path` varchar(500) DEFAULT NULL,
  `subtotal` decimal(14,2) DEFAULT '0.00',
  `tax_total` decimal(14,2) DEFAULT '0.00',
  `net_total` decimal(14,2) DEFAULT '0.00',
  `remarks` text,
  `terms_and_conditions` text,
  `special_notes` text,
  `inspection_clause` varchar(50) DEFAULT NULL,
  `test_certificate` varchar(50) DEFAULT NULL,
  `requesting_department_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `requesting_department_id` (`requesting_department_id`),
  CONSTRAINT `customer_pos_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `customer_pos_ibfk_2` FOREIGN KEY (`requesting_department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_pos`
--

LOCK TABLES `customer_pos` WRITE;
/*!40000 ALTER TABLE `customer_pos` DISABLE KEYS */;
INSERT INTO `customer_pos` VALUES (1,20,'PO-ABH-1768813663600','2026-01-19',NULL,NULL,NULL,'INR',NULL,NULL,NULL,NULL,NULL,NULL,'APPROVED',NULL,0.00,0.00,0.00,NULL,NULL,NULL,NULL,NULL,NULL,'2026-01-19 09:07:43');
/*!40000 ALTER TABLE `customer_pos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-20 13:51:06
